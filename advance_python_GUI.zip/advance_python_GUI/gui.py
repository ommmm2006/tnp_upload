from tkinter import *
root=Tk()
root.title("TNP File")
root.geometry("500x500+500+150")
root.config(background="#6CDEB8")
# root.iconbitmap("icon.ico")
e1= Entry(root)
e1.pack(side=BOTTOM)
root.mainloop()
