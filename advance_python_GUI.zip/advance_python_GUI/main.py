
from tkinter import *
from PIL import Image, ImageTk


def click_me():
    email = email_entry.get()
    password = password_entry.get()
    print("Email:", email)
    print("Password:", password)

    email_entry.delete(0, END)
    password_entry.delete(0, END)


root = Tk()
root.title("ammma jon")
root.iconbitmap("pixel3.ico")

root.geometry('500x500+0+0')
root.configure(background='#F3B61F')

# image
img = Image.open('amma.png')
resize_img = img.resize((105,90))
img = ImageTk.PhotoImage(resize_img)

img_label = Label(root,image = img)
img_label.pack(pady=10,padx=20)

# text label
text_label = Label(root,text="AMMA JON",font=('Arial', 18,'bold'),bg='#F3B61F',fg='white')
text_label.pack(pady=10,padx=20)

email_label = Label(root,text="AMMA NO.",font=('Arial', 18,'bold'),bg='#F3B61F',fg='white')
email_label.pack(pady=(20,5))

email_entry = Entry(root,font=('Arial', 18,'bold'),fg='white',bg='grey')
email_entry.pack(pady=(5,10))

password_label = Label(root,text="AMMA SECRET CODE",font=('Arial', 18,'bold'),bg='#F3B61F',fg='white')
password_label.pack(pady=(20,5))

password_entry = Entry(root,font=('Arial', 18,'bold'),fg='white',bg='grey')
password_entry.pack(pady=(5,10))

login_btn = Button(root,text="Login",font=('Arial', 18,'bold'),bg='orange',fg='white',command=click_me)
login_btn.pack(pady=(5,10))
login_btn.config(activebackground="red")
root.eval('tk::PlaceWindow . center')

root.mainloop()